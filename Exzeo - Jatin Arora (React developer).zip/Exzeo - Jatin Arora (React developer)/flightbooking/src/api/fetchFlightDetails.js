import axios from 'axios'

export default axios.create({
    baseURL: "https://www.googleapis.com/youtube/v3",
})

//This code is just to demonstrate the functionality of axios library.
// This code is not referenced in code anywhere.