export const addUser = (action) => {
    return {
        type : 'ADD_USER',
        payLoad: action
    } 
}