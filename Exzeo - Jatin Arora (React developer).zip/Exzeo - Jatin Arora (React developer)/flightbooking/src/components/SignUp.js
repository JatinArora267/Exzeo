import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { addUser } from '../actions'

class SignUp extends React.Component {
    constructor(){
        super();
        this.state = {
            user:{
                name: "",
                email: "",
                number: "",
                password: ""
            }
        }
        this.mail = React.createRef(); // ref is created to access the dom for a particular element
        this.onInputChange = this.onInputChange.bind(this); // Since onInputChange is not an arrow function we have to bind "this" keyword explicitly.
    }

    onFormSubmit = event => { 
        event.preventDefault();
        this.props.addUser(this.state); // Component emitting action to add details of an user.
    };

    onSignUpClick = event => {
        const name = this.state.user.name;
        const email = this.state.user.email;
        const number = this.state.user.number;
        const password = this.state.user.password;
        if(name === "" || email === "" || number === "" || password === ""){
            event.preventDefault();
            this.setState({ 
                error : true,
                errMessage : "Please fill up the form"
            })
        }
        else {
            this.setState({ 
                error : false,
                errMessage : ""
            })
        }
    }

    onInputChange (event){
        const id = event.target.id;
        const value = event.target.value;
        this.setState({
            user : {
                ...this.state.user,
                [id] : value
            }
        })
    }

    render(){
        return (
            <div>
                <form className="ui form" onSubmit={this.onFormSubmit}>
                    <div className="two fields">
                        <div className="field"><input id="name" type="text" placeholder="Enter Name" onChange={this.onInputChange}/></div>
                        <div className="field"><input id="email" ref={this.mail} type="text" placeholder="Enter Email" onKeyUp={this.onInputChange} /></div>
                    </div>
                    <div className="two fields">
                        <div className="field"><input id="number" type="text" placeholder="Enter Phone Number" onChange={this.onInputChange} /></div>
                        <div className="field"><input id="password" type="password" placeholder="Enter Password" onChange={this.onInputChange} /></div>
                    </div>
                    <div style={{height : "40px"}}>
                        <button type="submit" className="ui primary button" style={{float : "right"}} onClick={this.onSignUpClick}>Submit</button>
                        <Link to="/">
                            <button className="ui yellow button" style={{float : "left"}}>Back to Search</button>
                        </Link>
                    </div>
                    { this.state.error &&
                        <div className="ui compact message" style={{color : "red"}} >{this.state.errMessage}</div>
                    }
                </form>
            </div>
        )
    }
}
const mapStateToProps = state => {
    return { users: state.users };
}

export default connect(mapStateToProps, {addUser} ) (SignUp); // Connecting state to the component