import React from 'react';
import flightData from '../data/FlightData.json'


const FlightData = () => {

    return (
        <div style={{paddingTop : "25px"}}>
            <h2> Your search results are ready !!! </h2>
            <table className="ui celled table">
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Carrier Name</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Flight Duration</th>
                    <th>Price</th>
                    <th>Seats left</th>
                </tr>
            </thead>
                <tbody>
                    {flightData.map( data => (
                        <tr key={data.FlightNum}>
                            <td>{ data.FlightNum }</td>
                            <td>{ data.FlightName }</td>
                            <td>{ data.Departure }</td>
                            <td>{ data.ArrivalTime }</td>
                            <td>{ data.TotalDuration }</td>
                            <td>{ data.Price }</td>
                            <td>{ data.SeatAvailability }</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default FlightData;