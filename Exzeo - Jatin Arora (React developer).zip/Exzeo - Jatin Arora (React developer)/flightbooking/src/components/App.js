import React from 'react';
import { HashRouter as Router, Route } from 'react-router-dom';
import SearchFlight from './SearchFlight';
import SignUp from './SignUp'
import bookFlightBanner from '../images/bookYourFlightBanner.png'

class App extends React.Component{
    
    render(){
        return(
            <Router>
                <div className="ui container">
                    <img  src={bookFlightBanner} alt="bookFlightBanner" style={{ maxWidth : "100%" }}/>
                    <Route path="/" exact render={() => <SearchFlight />} />
                    <Route path="/signUp" render={() => <SignUp />} />
                </div>
            </Router>
        )
    }
}

export default App;