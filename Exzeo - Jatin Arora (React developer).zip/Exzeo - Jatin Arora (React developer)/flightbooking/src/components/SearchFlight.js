import React from 'react';
import DatePicker from 'react-date-picker';
import FlightData from './FlightData'
import { Link } from 'react-router-dom';
import FetchFlightDataAPI from '../api/fetchFlightDetails';

class SearchFlight extends React.Component{
    constructor(){
        super();
        this.state = {
            source : "",
            destination : "",
            date : new Date(),
            showSearchResult: false,
            error: false,
            errMessage: ""
        }
    }
    onDateChange = date => this.setState({ date });
    onFormSubmit = event => { 
        event.preventDefault()
        if(this.state.source === ""){
            this.setState({ 
                error : true,
                errMessage : "Please enter source"
            })
        }
        else if(this.state.destination === ""){
            this.setState({ 
                error : true,
                errMessage : "Please enter destination"
            })
        }
        else {
            this.setState({ 
                error : false,
                errMessage : ""
            })
        }
    };
    onInput = event => {
        switch (event.target.id){
            case 'source' : this.setState({ source : event.target.value }); break;
            case 'destination' : this.setState({ destination : event.target.value }); break;
            default : this.setState({ error : true }); break;
        }
    }

    // onSearchClick = async () => {
    //     const response = await FetchFlightDataAPI.get("/search");
    //     console.log(response);
    //     this.setState({ showSearchResult: true});
    // }

    //The above method can be used to make an API call to some endpoint to fetch flight data.

    render(){
        return(
            <div>
                <form onSubmit={this.onFormSubmit}>
                    <div className="ui input">
                        <input style={{marginRight : "10px"}} id="source" type="text" placeholder="Enter source" onChange={this.onInput} value={this.state.source} />
                        <input style={{marginRight : "10px"}} id="destination" type="text" placeholder="Enter destination" onChange={this.onInput} value={this.state.destination} />
                        <DatePicker onChange={this.onDateChange} value={this.state.date} />
                        <button style={{marginLeft : "10px"}} className="ui green button" 
                        onClick={() => this.setState({ showSearchResult: true})}>Search</button>
                        <Link to="/signUp">
                            <button className="ui blue button">SignUp</button>
                        </Link>
                    </div>
                    { this.state.error &&
                        <div className="ui compact message" style={{color : "red"}} >{this.state.errMessage}</div>
                    }
                    { this.state.showSearchResult && !this.state.error &&
                        <div>
                            <FlightData />
                        </div>
                    }
                </form>
            </div>
        )
    }
}

export default SearchFlight;