import { combineReducers } from 'redux';
import userReducer from './userReducer';

export default combineReducers({
    users : userReducer
});

// this is to combine all the reducers and pass it to store.