export default (state=[], action) => {
    switch(action.type){
        case 'ADD_USER':
            return [...state, action.payLoad.user];
        default:
            return state;
    }
}